import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import nltk
from nltk.tokenize import word_tokenize
import random
from torch.nn.utils.rnn import pad_sequence  # Import for padding sequences
import csv  # new import for CSV reading
import os   # already imported
from urllib.request import urlretrieve  # New import for downloading

# Import the model components
from app import Encoder, Attention, Decoder, Seq2Seq

nltk.download('punkt')

# --------------------------- #
# 🔹 Dataset Preparation #
# --------------------------- #

class SummarizationDataset(Dataset):
    def __init__(self, data, input_vocab, output_vocab):
        self.data = data
        self.input_vocab = input_vocab
        self.output_vocab = output_vocab

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        source, target = self.data[idx]
        source_ids = [self.input_vocab.get(token, 1) for token in word_tokenize(source.lower())]
        target_ids = [self.output_vocab.get(token, 1) for token in word_tokenize(target.lower())]
        return torch.tensor(source_ids), torch.tensor(target_ids)

def collate_fn(batch):
    """Custom collate function to pad sequences."""
    sources, targets = zip(*batch)
    sources_padded = pad_sequence(sources, batch_first=True, padding_value=0)  # Pad with <pad> token (index 0)
    targets_padded = pad_sequence(targets, batch_first=True, padding_value=0)
    return sources_padded, targets_padded

# --------------------------- #
# 🔹 Training Function #
# --------------------------- #

def train_model(model, dataloader, optimizer, criterion, device, epochs=10):
    model.train()
    for epoch in range(epochs):
        epoch_loss = 0
        for src, trg in dataloader:
            src, trg = src.to(device), trg.to(device)
            optimizer.zero_grad()
            # Using teacher_forcing_ratio=0 for simplicity. Adjust if needed.
            output = model(src, trg, teacher_forcing_ratio=0)
            output_dim = output.shape[-1]
            output = output[1:].view(-1, output_dim)
            trg = trg[:, 1:].contiguous().view(-1)
            loss = criterion(output, trg)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
        print(f"Epoch {epoch+1}/{epochs}, Loss: {epoch_loss/len(dataloader):.4f}")

# --------------------------- #
# 🔹 Main Training Script #
# --------------------------- #

if __name__ == "__main__":
    # Define the local path for the large dataset CSV
    large_data_file = os.path.join("data", "dataset_large.csv")
    
    # If the dataset file does not exist, create a synthetic dataset then save it and load it.
    if not os.path.exists(large_data_file):
        print("Synthetic dataset not found. Creating synthetic dataset...")
        synthetic_data = [
            ("Article about economy grows amid optimistic trends.", "Economy shows signs of recovery."),
            ("New breakthrough in AI research announced by scientists.", "Scientists announce AI breakthrough."),
            ("Local sports team wins championship after dramatic season.", "Team wins championship."),
            ("Government unveils plans to improve healthcare services.", "Government improves healthcare."),
            ("Technology companies show robust growth in Q2.", "Tech sector grows in Q2."),
            ("Environmental activists push for renewable energy sources.", "Activists support renewables."),
            ("New festival brings community together in celebration.", "Community celebrates local festival."),
            ("Study finds links between exercise and mental health improvement.", "Exercise boosts mental health."),
            ("Innovative startup introduces cutting-edge product to market.", "Startup launches new product."),
            ("Major policy changes expected to impact global trade dynamics.", "Policy changes affect trade.")
        ]
        os.makedirs(os.path.join("data"), exist_ok=True)
        with open(large_data_file, "w", encoding="utf8", newline="") as f:
            writer = csv.writer(f)
            # Write synthetic data without header
            for row in synthetic_data:
                writer.writerow(row)
        print(f"Synthetic dataset created at {large_data_file}")
    
    data = []
    if os.path.exists(large_data_file):
        with open(large_data_file, "r", encoding="utf8") as f:
            reader = csv.reader(f)
            # Uncomment the next line if your CSV file has a header
            # next(reader, None)
            for row in reader:
                # Expecting row[0]=article text, row[1]=summary
                if len(row) >= 2:
                    data.append((row[0], row[1]))
        print(f"Loaded {len(data)} examples from {large_data_file}")
    else:
        # Fall back to a toy dataset if creation fails
        data = [
            ("This is an example article.", "This is a summary."),
            ("Another article for training.", "Another summary."),
        ]
        print("Using toy dataset")
    
    # Build vocabularies
    input_vocab = {token: idx for idx, token in enumerate(set(word_tokenize(" ".join([d[0] for d in data]).lower())), start=2)}
    output_vocab = {token: idx for idx, token in enumerate(set(word_tokenize(" ".join([d[1] for d in data]).lower())), start=2)}

    # Add special tokens
    input_vocab["<pad>"] = 0
    input_vocab["<unk>"] = 1
    output_vocab["<pad>"] = 0
    output_vocab["<unk>"] = 1
    output_vocab["<sos>"] = len(output_vocab) + 2
    output_vocab["<eos>"] = len(output_vocab) + 3

    # Dataset and DataLoader
    dataset = SummarizationDataset(data, input_vocab, output_vocab)
    dataloader = DataLoader(dataset, batch_size=2, shuffle=True, collate_fn=collate_fn)  # Use custom collate_fn

    # Model parameters
    INPUT_DIM = len(input_vocab)
    OUTPUT_DIM = len(output_vocab)
    ENC_EMB_DIM = 256
    DEC_EMB_DIM = 256
    HID_DIM = 512
    N_LAYERS = 2
    ENC_DROPOUT = 0.5
    DEC_DROPOUT = 0.5

    # Initialize model
    attn = Attention(HID_DIM)
    enc = Encoder(INPUT_DIM, ENC_EMB_DIM, HID_DIM, N_LAYERS, ENC_DROPOUT)
    dec = Decoder(OUTPUT_DIM, DEC_EMB_DIM, HID_DIM, N_LAYERS, DEC_DROPOUT, attn)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = Seq2Seq(enc, dec, device).to(device)

    # Optimizer and loss function
    optimizer = optim.Adam(model.parameters())
    criterion = nn.CrossEntropyLoss(ignore_index=0)  # Ignore <pad> token

    # Train the model - increased epochs from 10 to 100
    train_model(model, dataloader, optimizer, criterion, device, epochs=100)

    # Save the model
    torch.save(model.state_dict(), "summarization_model.pth")
    print("Model training complete and saved as 'summarization_model.pth'.")
