from flask import Flask, render_template, request, jsonify
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen
from newspaper import Article
import nltk
from nltk.tokenize import word_tokenize
import os
import torch
import torch.nn as nn
import random
from bs4 import BeautifulSoup  # Import BeautifulSoup for fallback scraping

nltk.download('punkt')
nltk.download('punkt_tab')  # Ensure 'punkt_tab' resource is downloaded
print("path",nltk.data.path)
app = Flask(__name__)

# --------------------------- #
# 🔹 FETCH NEWS FROM GOOGLE RSS #
# --------------------------- #

def fetch_news_search_topic(topic):
    """Fetch news articles for a given search topic from Google News RSS."""
    topic = topic.replace(" ", "%20")
    site = f'https://news.google.com/rss/search?q={topic}'
    try:
        op = urlopen(site)
        rd = op.read()
        op.close()
        sp_page = soup(rd, 'xml')
        return sp_page.find_all('item')
    except Exception as e:
        print(f"❌ Error fetching news: {e}")
        return []

def fetch_top_news():
    """Fetch top global news from Google News RSS."""
    site = 'https://news.google.com/rss'
    try:
        op = urlopen(site)
        rd = op.read()
        op.close()
        sp_page = soup(rd, 'xml')
        return sp_page.find_all('item')
    except Exception as e:
        print(f"❌ Error fetching news: {e}")
        return []

def display_news(news_list, news_quantity):
    """Extracts details from news articles and generates summaries."""
    response = []
    for i, news in enumerate(news_list[:news_quantity]):
        article = Article(news.link.text)
        try:
            article.download()
            article.parse()
            if not article.text.strip():
                print(f"⚠ Article content is empty for {news.link.text}. Using title for fallback summarization.")
            # Fallback: Use BeautifulSoup if article.text is empty
            if not article.text.strip():
                print(f"⚠ Article content is empty for {news.link.text}. Attempting fallback scraping...")
                html = urlopen(news.link.text).read()
                soup_page = BeautifulSoup(html, 'html.parser')
                paragraphs = soup_page.find_all('p')
                if not paragraphs:
                    print(f"⚠ No <p> tags found for article: {news.link.text}. Trying <div> tags.")
                    paragraphs = soup_page.find_all('div')
                if not paragraphs:
                    paragraphs = soup_page.find_all('article')
                article.text = ' '.join([p.get_text() for p in paragraphs if p.get_text()]).strip()
                # Extended fallback if still empty using multiple tags
                if not article.text.strip():
                    print(f"⚠ Extended fallback for {news.link.text}")
                    content = []
                    for tag in ['p', 'div', 'section', 'article']:
                        elements = soup_page.find_all(tag)
                        for el in elements:
                            text_el = el.get_text(separator=" ", strip=True)
                            if text_el:
                                content.append(text_el)
                    article.text = ' '.join(content).strip()
                    # Final fallback: use entire body text if still empty
                    if not article.text.strip():
                        print(f"❌ Content still empty after extended fallback for {news.link.text}. Using raw body text fallback.")
                        article.text = soup_page.get_text(separator=" ", strip=True)
            if not article.text.strip():
                print(f"❌ Article content is still empty for {news.link.text}. Skipping...")
                summary = "Content not available."
            else:
                if article.text.strip().lower() == "google news":
                    print(f"❌ Article contains only 'Google News' for {news.link.text}")
                    article.text = news.title.text + " - No additional content available."
                print(f"🔹 Generating summary for article: {news.title.text}")
                print(f"Article text starts with: {article.text[:50]}...")
                summary = generate_summary(article.text)
                print(f"✅ Summary: {summary}")
                if summary.strip().lower() == "google news":
                    summary = f"Summary could not be generated for: {news.title.text}"
        except Exception as e:
            print(f"⚠ Error fetching or summarizing article: {e}")
            summary = "Summary not available."

        response.append({
            "news_id": f"News_{i+1}",
            "news_title": news.title.text,
            "news_link": news.link.text,
            "news_source": news.source.text if news.source else "Unknown",
            "news_date": news.pubDate.text,
            "news_image": article.top_image if article.top_image else "",
            "news_content": article.text,
            "news_summary": summary
        })
    return response

# --------------------------- #
# 🔹 EXTRACTIVE SUMMARIZATION MODEL #
# --------------------------- #

class Encoder(nn.Module):
    def __init__(self, input_dim, emb_dim, hid_dim, n_layers, dropout):
        super().__init__()
        self.embedding = nn.Embedding(input_dim, emb_dim)
        self.rnn = nn.LSTM(emb_dim, hid_dim, n_layers, dropout=dropout)
        self.dropout = nn.Dropout(dropout)

    def forward(self, src):
        embedded = self.dropout(self.embedding(src))
        outputs, (hidden, cell) = self.rnn(embedded)
        return hidden, cell, outputs

class Attention(nn.Module):
    def __init__(self, hid_dim):
        super().__init__()
        self.attn = nn.Linear((hid_dim * 2), hid_dim)
        self.v = nn.Linear(hid_dim, 1, bias=False)

    def forward(self, hidden, encoder_outputs):
        # Ensure hidden and encoder_outputs have compatible dimensions
        src_len = encoder_outputs.shape[0]  # Sequence length of encoder outputs
        batch_size = encoder_outputs.shape[1]  # Batch size
        encoder_outputs = encoder_outputs.permute(1, 0, 2)  # (batch_size, src_len, hid_dim)
        # Repeat the hidden state across the sequence length
        hidden = hidden[-1].unsqueeze(1).repeat(1, src_len, 1)  # (batch_size, src_len, hid_dim)
        # Concatenate hidden and encoder_outputs along the last dimension
        energy = torch.tanh(self.attn(torch.cat((hidden, encoder_outputs), dim=2)))  # (batch_size, src_len, hid_dim)
        # Compute attention scores
        attention = self.v(energy).squeeze(2)  # (batch_size, src_len)
        return torch.softmax(attention, dim=1)

class Decoder(nn.Module):
    def __init__(self, output_dim, emb_dim, hid_dim, n_layers, dropout, attention):
        super().__init__()
        self.output_dim = output_dim
        self.attention = attention
        self.embedding = nn.Embedding(output_dim, emb_dim)
        self.rnn = nn.LSTM((emb_dim + hid_dim), hid_dim, n_layers, dropout=dropout)
        self.fc_out = nn.Linear((hid_dim * 2) + emb_dim, output_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, input, hidden, cell, encoder_outputs):
        input = input.unsqueeze(0)  # (1, batch_size)
        embedded = self.dropout(self.embedding(input))  # (1, batch_size, emb_dim)
        # Compute attention weights
        a = self.attention(hidden, encoder_outputs)  # (batch_size, src_len)
        a = a.unsqueeze(1)  # (batch_size, 1, src_len)
        # Transpose encoder_outputs to match dimensions for torch.bmm
        encoder_outputs = encoder_outputs.permute(1, 0, 2)  # (batch_size, src_len, hid_dim)
        # Compute weighted sum of encoder outputs
        weighted = torch.bmm(a, encoder_outputs)  # (batch_size, 1, hid_dim)
        # Match the sequence length of embedded (1) with weighted
        weighted = weighted.permute(1, 0, 2)  # (1, batch_size, hid_dim)
        # Concatenate embedded input and weighted encoder outputs
        rnn_input = torch.cat((embedded, weighted), dim=2)  # (1, batch_size, emb_dim + hid_dim)
        # Pass through the RNN
        output, (hidden, cell) = self.rnn(rnn_input, (hidden, cell))
        # Compute prediction
        embedded = embedded.squeeze(0)  # (batch_size, emb_dim)
        output = output.squeeze(0)  # (batch_size, hid_dim)
        weighted = weighted.squeeze(0)  # (batch_size, hid_dim)
        prediction = self.fc_out(torch.cat((output, weighted, embedded), dim=1))  # (batch_size, output_dim)
        return prediction, hidden, cell

class Seq2Seq(nn.Module):
    def __init__(self, encoder, decoder, device):
        super().__init__()
        self.encoder = encoder
        self.decoder = decoder
        self.device = device

    def forward(self, src, trg, teacher_forcing_ratio=0.5):
        # Transpose to shape: (seq_len, batch_size)
        src = src.permute(1, 0)
        trg = trg.permute(1, 0)
        trg_len = trg.shape[0]
        batch_size = trg.shape[1]
        trg_vocab_size = self.decoder.output_dim
        # Create outputs tensor with shape (trg_len, batch_size, trg_vocab_size)
        outputs = torch.zeros(trg_len, batch_size, trg_vocab_size).to(self.device)
        hidden, cell, encoder_outputs = self.encoder(src)
        input = trg[0]
        for t in range(1, trg_len):
            output, hidden, cell = self.decoder(input, hidden, cell, encoder_outputs)
            outputs[t] = output
            teacher_force = random.random() < teacher_forcing_ratio
            top1 = output.argmax(1)
            input = trg[t] if teacher_force else top1
        return outputs

# Example usage
INPUT_DIM = 10000  # Example input dimension
OUTPUT_DIM = 10000  # Example output dimension
ENC_EMB_DIM = 256
DEC_EMB_DIM = 256
HID_DIM = 512
N_LAYERS = 2
ENC_DROPOUT = 0.5  # Corrected dropout value
DEC_DROPOUT = 0.5  # Corrected dropout value

attn = Attention(HID_DIM)
enc = Encoder(INPUT_DIM, ENC_EMB_DIM, HID_DIM, N_LAYERS, ENC_DROPOUT)
dec = Decoder(OUTPUT_DIM, DEC_EMB_DIM, HID_DIM, N_LAYERS, DEC_DROPOUT, attn)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = Seq2Seq(enc, dec, device).to(device)

def tokenize_and_map(text):
    """Tokenize the text and map tokens to ids."""
    tokens = nltk.word_tokenize(text.lower())
    token_map = {token: idx for idx, token in enumerate(set(tokens), start=2)}
    token_ids = [token_map.get(token, 1) for token in tokens]  # Use 1 for unknown tokens
    return token_ids, token_map

def generate_summary(text):
    # Try loading trained model if it exists
    model_path = "summarization_model.pth"
    try:
        if os.path.exists(model_path):
            print("Loading trained model...")
            model.load_state_dict(torch.load(model_path, map_location=device))
            # Continue with model-based summarization
            token_ids, token_map = tokenize_and_map(text)
            src_tensor = torch.LongTensor(token_ids).unsqueeze(1).to(device)
            # Generate summary using the trained model
            model.eval()
            with torch.no_grad():
                trg_indices = [0]  # Start with the <sos> token
                for _ in range(100):  # Limit the summary length
                    trg_tensor = torch.LongTensor(trg_indices).unsqueeze(1).to(device)
                    output = model(src_tensor, trg_tensor, 0)  # Turn off teacher forcing
                    pred_token = output.argmax(2)[-1, 0].item()  # Extract token id
                    trg_indices.append(pred_token)
                    if pred_token == 1:  # If <eos> token is generated
                        break
            # Convert token ids back to words based on generated indices
            model_summary = ' '.join([token for idx, token in token_map.items() if idx in trg_indices])
            
            # If model summary is good enough, return it
            if len(model_summary.split()) > 5:
                return model_summary
            
            print("Model summary too short, falling back to extractive summarization")
        else:
            print("No trained model found, using extractive summarization")
    except Exception as e:
        print(f"Error using trained model: {e}, falling back to extractive summarization")
    
    # Check if the text contains only "Google News" and replace with article title if needed
    if text.strip().lower() == "google news":
        print("Text contains only 'Google News', cannot generate meaningful summary")
        return "Article content unavailable for summarization."
    
    # Extractive fallback summarization
    from nltk.corpus import stopwords
    from nltk.cluster.util import cosine_distance
    import numpy as np
    import networkx as nx
    
    # Download stopwords if needed
    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        nltk.download('stopwords')
    
    stop_words = set(stopwords.words('english'))
    
    def sentence_similarity(sent1, sent2, stop_words):
        sent1 = [w.lower() for w in sent1 if w.lower() not in stop_words]
        sent2 = [w.lower() for w in sent2 if w.lower() not in stop_words]
        
        all_words = list(set(sent1 + sent2))
        
        vector1 = [0] * len(all_words)
        vector2 = [0] * len(all_words)
        
        # Build the vector for the first sentence
        for w in sent1:
            if w in all_words:
                vector1[all_words.index(w)] += 1
        
        # Build the vector for the second sentence
        for w in sent2:
            if w in all_words:
                vector2[all_words.index(w)] += 1
        
        # Calculate cosine similarity
        if sum(vector1) == 0 or sum(vector2) == 0:
            return 0.0
        return 1 - cosine_distance(vector1, vector2)
    
    def build_similarity_matrix(sentences, stop_words):
        # Create an empty similarity matrix
        similarity_matrix = np.zeros((len(sentences), len(sentences)))
        
        for idx1 in range(len(sentences)):
            for idx2 in range(len(sentences)):
                if idx1 == idx2: # Same sentence
                    similarity_matrix[idx1][idx2] = 1.0
                else:
                    similarity_matrix[idx1][idx2] = sentence_similarity(
                        sentences[idx1], sentences[idx2], stop_words)
        
        return similarity_matrix
    
    def generate_extractive_summary(text, num_sentences=3):
        # Split text into sentences and tokenize each sentence
        sentences = nltk.sent_tokenize(text)
        
        # Print for debugging
        print(f"Extractive summarization found {len(sentences)} sentences")
        
        # Return original text if too short
        if len(sentences) <= num_sentences:
            if len(sentences) > 0:  # If there's at least one sentence
                return " ".join(sentences)
            else:
                return "No content available for summarization."
        
        # Tokenize each sentence into words
        sentence_words = [nltk.word_tokenize(sentence) for sentence in sentences]
        
        # Calculate similarity matrix
        try:
            similarity_matrix = build_similarity_matrix(sentence_words, stop_words)
            
            # Apply PageRank algorithm to find most important sentences
            nx_graph = nx.from_numpy_array(similarity_matrix)
            scores = nx.pagerank(nx_graph)
            
            # Sort sentences by score and select top ones
            ranked_sentences = sorted(((scores[i], i, s) for i, s in enumerate(sentences)), reverse=True)
            summary_sentences = [ranked_sentences[i][2] for i in range(min(num_sentences, len(ranked_sentences)))]
            
            # Sort the selected sentences by their original order in the text
            summary_sentences = sorted(summary_sentences, key=lambda s: sentences.index(s))
            
            # Return the summary
            result = " ".join(summary_sentences)
            print(f"Generated extractive summary: {result[:50]}...")
            return result
        except Exception as e:
            print(f"Error in extractive summarization: {e}")
            # If extractive summarization fails, return a few sentences from the beginning
            return ". ".join(sentences[:min(2, len(sentences))])
    
    # Generate and return the extractive summary
    return generate_extractive_summary(text)

# --------------------------- #
# 🔹 FLASK ROUTES #
# --------------------------- #

@app.route('/')
def home_page():
    """Renders home page with top news."""
    news_list = fetch_top_news()
    response = display_news(news_list, 5)
    return render_template('home.html', response=response, languages=["en", "hi", "es", "fr", "de", "zh"])

@app.route('/search', methods=['POST'])
def search_news():
    """Search for news based on user input."""
    topic = request.form.get("topic", "")
    num_articles = int(request.form.get("num_articles", 5))
    if not topic:
        return render_template("home.html", response=[], error="❌ Please enter a search topic.")
    news_list = fetch_news_search_topic(topic)
    response = display_news(news_list, num_articles)
    return render_template("home.html", response=response, topic=topic, languages=["en", "hi", "es", "fr", "de", "zh"])

@app.route('/summarize', methods=['POST'])
def summarize_news():
    data = request.get_json()
    news_link = data.get("link", "")
    language = data.get("language", "en")
    print(f"Received link: {news_link}")
    if not news_link:
        print("❌ No link provided.")
        return jsonify({"error": "No link provided"})
    try:
        # Extract the actual article link from Google News RSS
        if "news.google.com/rss/articles" in news_link:
            article_page = urlopen(news_link)
            actual_url = article_page.geturl()  # Gets the redirected URL
        else:
            actual_url = news_link
        print(f"🔗 Actual Article URL: {actual_url}")
        article = Article(actual_url)
        article.download()
        article.parse()
        if not article.text.strip():
            print("⚠ Article content is still empty after fallback, using title as fallback for summarization.")
            article.text = article.title if article.title else "No content available."
        tokens = word_tokenize(article.text)
        full_text = " ".join(tokens)
        print("🔹 Input received:", full_text[:500])  # Print first 500 chars for debugging
        summary = generate_summary(full_text)
        print("✅ Generated Summary:", summary)
        translated_summary = summary
        print("🌍 Translated Summary:", translated_summary)
        return jsonify({"summary": summary, "translated_summary": translated_summary})
    except Exception as e:
        print(f"❌ Summarization failed: {e}")
        return jsonify({"error": f"Summarization failed: {e}"})

@app.route('/summarize_text', methods=['POST'])
def summarize_text():
    """Summarizes raw text provided in the POST JSON payload."""
    data = request.get_json()
    text = data.get("text", "")
    if not text:
        return jsonify({"error": "No text provided"}), 400
    summary = generate_summary(text)
    return jsonify({"summary": summary})

# Test the summarization model with static text
if __name__ == "__main__":
    test_text = "This is a test article content to verify the summarization model. The model should generate a concise summary of this text."
    print("Testing summarization model...")
    print("Generated Summary:", generate_summary(test_text))
    port = int(os.environ.get("PORT", 5000))
    app.run(host='127.0.0.1', port=port, debug=True)