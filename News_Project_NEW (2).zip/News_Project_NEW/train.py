import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset

# Sample dataset (Replace with real dataset)
class SampleDataset(Dataset):
    def __init__(self):
        self.data = [
            ("This is a long text that needs summarization.", "Text summarization."),
            ("PyTorch is an open-source machine learning framework.", "ML framework."),
        ]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

# Simple LSTM-based model
class AbstractiveSummarizer(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(AbstractiveSummarizer, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        _, (hidden, _) = self.lstm(x)
        output = self.fc(hidden[-1])
        return output

# Training
def train_model():
    dataset = SampleDataset()
    dataloader = DataLoader(dataset, batch_size=2, shuffle=True)

    input_size, hidden_size, output_size = 50, 128, 20
    model = AbstractiveSummarizer(input_size, hidden_size, output_size)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    for epoch in range(5):  # Training for 5 epochs
        for text, summary in dataloader:
            optimizer.zero_grad()
            output = model(torch.randn(2, 10, input_size))  # Fake input tensor
            loss = criterion(output, torch.randn(2, output_size))  # Fake target tensor
            loss.backward()
            optimizer.step()
        print(f"Epoch {epoch+1}, Loss: {loss.item()}")

    # Save the trained model
    torch.save(model.state_dict(), "abstractive_model.pth")
    print("Model saved as 'abstractive_model.pth'")

if __name__ == "__main__":
    train_model()
