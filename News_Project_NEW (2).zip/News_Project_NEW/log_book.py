from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import datetime

def create_weekly_summary():
    # Create a new PDF document
    doc = SimpleDocTemplate("weekly_progress_summary.pdf", pagesize=letter)
    
    # Create a list to hold the elements
    elements = []
    
    # Get styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=20,
        spaceAfter=30,
        alignment=1  # Center alignment
    )
    
    # Add title
    title = Paragraph("11-Week Progress Summary", title_style)
    elements.append(title)
    
    # Create table style
    table_style = TableStyle([
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('BACKGROUND', (1, 0), (1, -1), colors.white),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
        ('LEADING', (0, 0), (-1, -1), 20),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
    ])
    
    # Create weekly summaries
    for week in range(1, 12):  # Weeks 1 through 11
        # Add week number
        week_title = Paragraph(f"Week {week}", styles['Heading2'])
        elements.append(week_title)
        elements.append(Spacer(1, 0.2*inch))
        
        # Create table data
        data = [
            ['Planned Activities', 'Completed Activities'],
            ['', ''],
            ['', ''],
            ['', ''],
            ['', ''],
            ['', ''],
            ['', ''],
            ['', ''],
            ['', ''],
            ['', ''],
        ]
        
        # Create table
        table = Table(data, colWidths=[3.5*inch, 3.5*inch])
        table.setStyle(table_style)
        elements.append(table)
        
        # Add date range
        date_line = Paragraph(f"Date Range: _________________ to _________________", styles['Normal'])
        elements.append(Spacer(1, 0.3*inch))
        elements.append(date_line)
        
        # Add page break if not the last week
        if week < 11:
            elements.append(Spacer(1, 0.5*inch))
    
    # Build the PDF
    doc.build(elements)

if __name__ == "__main__":
    create_weekly_summary()
    print("Weekly progress summary has been created as 'weekly_progress_summary.pdf'") 